# portal/filters.py
import django_filters as df
from django import forms
from fila_cirurgica.models import (
    ListaEsperaCirurgica,
    EspecialidadeAghu as Especialidade,
    ProcedimentoAghu as Procedimento,
    ProfissionalAghu as Profissional,
)

class FilaFilter(df.FilterSet):
    especialidade = df.ModelMultipleChoiceFilter(
        label="Especialidade",
        queryset=Especialidade.objects.order_by("nome_especialidade"),
        widget=forms.SelectMultiple(attrs={"id": "id_especialidade"}),
    )    

    procedimento = df.ModelMultipleChoiceFilter(
        label="Procedimento",
        field_name="procedimento",
        queryset=Procedimento.objects.order_by("nome"),
        widget=forms.SelectMultiple(attrs={"id": "id_procedimento"}),
    )
    medico = df.ModelMultipleChoiceFilter(
        label="Médico",
        field_name="medico",
        queryset=Profissional.objects.order_by("nome"),
        widget=forms.SelectMultiple(attrs={"id": "id_medico"}),
    )

    class Meta:
        model  = ListaEsperaCirurgica
        fields = ["medico", "prioridade", "ativo",
                  "medida_judicial", "data_entrada"]
